package com.cybertek.step_definitions;

import com.cybertek.pages.TrainPickList;
import com.cybertek.utilities.Driver;
import cucumber.api.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import static com.cybertek.step_definitions.MenuParsStepDefinition.departureDate;
import static com.cybertek.step_definitions.MenuParsStepDefinition.warehouse;

public class TrainPickListStepDefinition {
    TrainPickList trainPickList= new TrainPickList();
    public static String Train;

    @Then("pick the Train with the arrival date {string} and train {string}")
    public void pick_the_Train_with_the_arrival_date_and_train(String arrivalDate, String train) throws InterruptedException {
        Train=train;
        trainPickList.InventoryTransfers.click();
        trainPickList.trainTransersPageBTN.click();
//        trainPickList.trianPickListBTN.click();
//        Select select= new Select(trainPickList.departureWarehouse);
//        select.selectByVisibleText(warehouse);
//        System.out.println("warehouse info from TrainpicklistStepDefinition "+warehouse);
//        trainPickList.searchtrain.sendKeys(train + Keys.ENTER);
//
//        Actions actions= new Actions(Driver.getDriver());
//        Thread.sleep(4000);
//        trainPickList.departureDateBtn.click();
//
//        actions.moveToElement(Driver.getDriver().findElement(By.xpath("//*[text()='"+departureDate+"']"))).click().perform();
//        trainPickList.arrivalDateBtn.click();
//        Thread.sleep(2000);
//        actions.moveToElement(Driver.getDriver().findElement(By.xpath("//table[@id='ctl00_MainContentPlaceHolder_ce_dpArrivalDate_daysTable']//*[text()='"+arrivalDate+"']"))).click().perform();
//        Thread.sleep(1000);
//        trainPickList.creatPickListBtn.click();
    }
}
