package com.cybertek.step_definitions;


import com.cybertek.pages.MenuPars;
import com.cybertek.pages.TrainPickList;
import com.cybertek.utilities.ConfigurationReader;
import com.cybertek.utilities.Driver;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import javax.swing.*;
import javax.swing.text.html.Option;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;

public class MenuParsStepDefinition {
    public static String warehouse;
    public static String departureDate;
    MenuPars menuPars = new MenuPars();
    TrainPickList trainPickList= new TrainPickList();

    @When("User should be able to log in")
    public void user_should_be_able_to_log_in() {
        Driver.getDriver().get("http://"+ ConfigurationReader.getProperty("username")
                +":"+ConfigurationReader.getProperty("password")+"@fbwims-s.amtrak.ad.nrpc/TrainTrip/TrainTransferOutSelection.aspx");

    }
    @When("Menu and pars")
    public void menu_and_pars() throws InterruptedException  {

        menuPars.MenuPARs.click();
        Thread.sleep(3000);
        menuPars.PARs.click();
        menuPars.parCalendarAssignment.click();
    }

    @Then("Select the Train {string} Start date {string} end date {string}")
    public void select_the_Train_Start_date_end_date(String train, String startDate, String endDate) throws InterruptedException {

        Select select = new Select((menuPars.train));
        select.selectByVisibleText(train);
        Thread.sleep(1000);
        departureDate=startDate;


        System.out.println(warehouse);
        menuPars.starDateEl.clear();
//        menuPars.starDateEl.sendKeys(startDate);
//
//        menuPars.endDateEl.sendKeys(endDate);
        Thread.sleep(1000);
        menuPars.starDateEl.click();

//        Actions action= new Actions(Driver.getDriver());
//        action.moveToElement(Driver.getDriver().findElement(By.id("ctl00_MainContentPlaceHolder_ce_dpStartDate_nextArrow"))).click().perform();
//        Thread.sleep(3000);
//        action.moveToElement(Driver.getDriver().findElement(By.id("ctl00_MainContentPlaceHolder_ce_dpStartDate_nextArrow"))).click().perform();
//
//
//        action.moveToElement(Driver.getDriver().findElement(By.xpath("//*[text()='"+startDate+"']"))).click().perform();
//        Thread.sleep(3000);
        menuPars.starDateEl.clear();
        Thread.sleep(2000);
        menuPars.starDateEl.sendKeys("08022019");
        Thread.sleep(2000);
        Actions actions= new Actions(Driver.getDriver());
        actions.moveToElement(Driver.getDriver().findElement(By.xpath("//input[@name='ctl00$MainContentPlaceHolder$dpEndDate']"))).click().perform();
//        menuPars.endDateEl.click();
//        action.moveToElement(Driver.getDriver().findElement(By.id("ctl00_MainContentPlaceHolder_ce_dpEndDate_nextArrow"))).click().perform();
//        Thread.sleep(3000);
//        action.moveToElement(Driver.getDriver().findElement(By.id("ctl00_MainContentPlaceHolder_ce_dpEndDate_nextArrow"))).click().perform();
//        Thread.sleep(2000);
//        action.moveToElement(Driver.getDriver().findElement(By.xpath("//*[text()='"+endDate+"']"))).click().perform();
        Thread.sleep(1000);
//        menuPars.endDateEl.click();
        Thread.sleep(1000);
        menuPars.endDateEl.clear();
        Thread.sleep(1000);
        menuPars.endDateEl.sendKeys("08052019");
        Thread.sleep(1000);

        warehouse = menuPars.warehouseEl.getText();



//        Driver.getDriver().findElement(By.xpath("//span[@id='ctl00_MainContentPlaceHolder_lvCarNumbers_ctrl7_placeHolderId']")).click();

//        for (int i = 1; i <3; i++) {
//            if (Driver.getDriver().findElement(By.xpath("//span[@id='ctl00_MainContentPlaceHolder_lvCarNumbers_ctrl" + i + "_placeHolderId']"))_placeHolderId.isSelected())
        Driver.getDriver().findElement(By.xpath("//span[@id='ctl00_MainContentPlaceHolder_lvCarNumbers_ctrl1_placeHolderId']")).click();
        Thread.sleep(2000);
        Driver.getDriver().findElement(By.xpath("//span[@id='ctl00_MainContentPlaceHolder_lvCarNumbers_ctrl2_placeHolderId']")).click();
        Select select1= new Select(menuPars.parTemplate);
        select1.selectByValue("6473");
        Thread.sleep(2000);

        select1.selectByValue("6473");
        Thread.sleep(2000);

//        }

        menuPars.selectWeekDay.click();
        menuPars.assign.click();
    }


}

