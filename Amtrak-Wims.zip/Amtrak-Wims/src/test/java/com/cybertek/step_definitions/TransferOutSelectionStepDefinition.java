//package com.cybertek.step_definitions;
//import com.cybertek.pages.TransferOutSelection;
//import com.cybertek.utilities.Driver;
//import cucumber.api.java.en.Then;
//import org.openqa.selenium.By;
//import org.openqa.selenium.support.ui.Select;
//
//import static com.cybertek.step_definitions.MenuParsStepDefinition.warehouse;
//import static com.cybertek.step_definitions.TrainPickListStepDefinition.Train;
//
//public class TransferOutSelectionStepDefinition {
//    TransferOutSelection transferOutSelection= new TransferOutSelection();
//    @Then("Train Transfer Out Selection")
//    public void train_Transfer_Out_Selection() {
//        transferOutSelection.trasferOutSelectionPageBtn.click();
//        Select select= new Select(transferOutSelection.TOSwarehouse);
//        select.selectByVisibleText(warehouse);
//        transferOutSelection.TOSsearchBtn.sendKeys(Train);
//        Driver.getDriver().findElement(By.xpath("//table[@class='helper_grid']//*[text()='"+Train+"']")).click();
//        transferOutSelection.selectBtn.click();
//    }
//}
