package com.cybertek.utilities;

public class ApplicationConstants {

    public static final String DARK_SIDE = "dark-side";
    public static final String LIGHT_SIDE = "light-side";
    public static final String IL = "il";

    public static final String TEACHER = "teacher";
    public static final String STUDENT_TEAM_LEADER = "student-team-leader";
    public static final String STUDENT_TEAM_MEMBER = "student-team-member";

}
