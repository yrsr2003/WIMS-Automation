package com.cybertek.pages;

import com.cybertek.utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public abstract class NavigationMenu {

    public NavigationMenu() {
        PageFactory.initElements(Driver.getDriver(),
                this);
    }

    @FindBy(linkText = "Menu & PARs")
    public WebElement MenuPARs;

    @FindBy(linkText = "Inventory Transfers")
    public WebElement InventoryTransfers;




    public void goToMenuPars() {
        Actions actions = new Actions(Driver.getDriver());
        actions.moveToElement(MenuPARs).perform();
        MenuPARs.click();
    }

    public void goToInventoryTransfers() {
        Actions actions = new Actions(Driver.getDriver());
        actions.moveToElement(InventoryTransfers).perform();
        InventoryTransfers.click();
    }



}
