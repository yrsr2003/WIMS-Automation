package com.cybertek.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TransferOutSelection extends NavigationMenu {

    @FindBy(linkText = "Transfer Out Selection")
    public WebElement trasferOutSelectionPageBtn;

    @FindBy(xpath = "//select[@name='ctl00$MainContentPlaceHolder$drdWarehouse']")
    public WebElement TOSwarehouse;

    @FindBy(xpath = "//input[@name='ctl00$MainContentPlaceHolder$sbUnassigned']")
    public WebElement TOSsearchBtn;

    @FindBy(xpath = "//input[@name='ctl00$MainContentPlaceHolder$btnAdd']")
    public WebElement selectBtn;


}
