package com.cybertek.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TrainPickList extends NavigationMenu {

    @FindBy(linkText = "Train Transfers")
    public WebElement trainTransersPageBTN;

    @FindBy(linkText = "Train Pick List")
    public WebElement trianPickListBTN;

    @FindBy(xpath = "//select[@name='ctl00$MainContentPlaceHolder$drdWarehouse']")
    public WebElement departureWarehouse;

    @FindBy(id = "ctl00_MainContentPlaceHolder_sbMain")
    public WebElement searchtrain;

    @FindBy(xpath="//input[@name='ctl00$MainContentPlaceHolder$dpDepDate']")
    public WebElement departureDateBtn;

    @FindBy(xpath = "//input[@name='ctl00$MainContentPlaceHolder$dpArrivalDate']")
    public WebElement arrivalDateBtn;

    @FindBy(xpath = "//input[@name='ctl00$MainContentPlaceHolder$btnCreate']")
    public WebElement creatPickListBtn;






}
