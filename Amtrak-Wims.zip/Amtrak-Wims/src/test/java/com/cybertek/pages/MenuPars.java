package com.cybertek.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MenuPars extends NavigationMenu {

    @FindBy(linkText = "PARs")
    public WebElement PARs;

    @FindBy(linkText = "PAR Calendar Assignment")
    public WebElement parCalendarAssignment;

    @FindBy(xpath = "//select[@name='ctl00$MainContentPlaceHolder$drdTrain']")
    public WebElement train;

    @FindBy(id = "ctl00_MainContentPlaceHolder_txtWarehouse")
    public WebElement warehouseEl;

//    @FindBy(id="")
//    public WebElement CarNumberEl;

    @FindBy(id = "ctl00_MainContentPlaceHolder_drdTemplate")
    public WebElement parTemplate;

    @FindBy(xpath = "//table[@id='ctl00_MainContentPlaceHolder_gvWeekdays']//tr[1]//td[1]")
    public WebElement selectWeekDay;

    @FindBy(id="ctl00_MainContentPlaceHolder_btnAssign")
    public WebElement assign;

    @FindBy (xpath = "//input[@name='ctl00$MainContentPlaceHolder$dpStartDate']")
    public WebElement starDateEl;

    @FindBy(xpath = "//input[@id='ctl00_MainContentPlaceHolder_dpEndDate']")
    public WebElement endDateEl;

    @FindBy(id="ctl00_MainContentPlaceHolder_ce_dpStartDate_nextArrow")
    public WebElement nextBtn;
}
